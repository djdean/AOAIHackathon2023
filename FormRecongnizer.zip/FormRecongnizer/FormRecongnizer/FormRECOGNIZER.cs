﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Azure;
using Azure.AI.FormRecognizer;
using Azure.AI.FormRecognizer.DocumentAnalysis;
using Azure.AI.FormRecognizer.Models;
using Azure.Core;
using Azure.AI;
using Azure.AI.OpenAI;
using System.Net;
using Newtonsoft.Json.Linq;
using System.Collections;

using NRedisStack;
using NRedisStack.RedisStackCommands;
using StackExchange.Redis;
using System.Numerics;
using Microsoft.Extensions.Azure;
using NRedisStack.Search;
using static NRedisStack.Search.Schema;
using NRedisStack.Search.Literals.Enums;

namespace FormRecongnizer
{
    public class FormRECOGNIZER
    {
        private string _endpoint = "";
        private string _subscriptionKey = "";
        private Uri _fileUri = new Uri(@"https://azureblobstorageht.blob.core.windows.net/openaihackathon/ICD-10-CM-Guidelines-April 1, FY2023.pdf");
        private Uri _file2 = new Uri(@"https://azureblobstorageht.blob.core.windows.net/openaihackathon/bp102c09.pdf");

        private string _EmbeddingsEndPoint = "";
        private string _EmbeddingKey = "";

        // Vitas Version private string _RedisEndPoint = "hackathon.redis.cache.windows.net:6380,password=oCoFI61sVssVR0lxBZUy0JPIZ4dpG1ZJ8AzCaNPTrPw=,ssl=True,abortConnect=False,syncTimeout=5000";
        //hack2023AI.eastus.redisenterprise.cache.azure.net:10000
        private string _RedisEndPoint = "";        private List<string> SplitWordsIntoChunks(string[] words, int ChunkSize)
        {
            List<string> vResponse = new List<string>();
            StringBuilder vTempBuilder = new StringBuilder();
            int vCount = 0;
            foreach (string vWord in words)
            {
                if (vCount > ChunkSize)
                {
                    // Reset the counter and add the string to the list
                    vResponse.Add(vTempBuilder.ToString());
                    vTempBuilder = new StringBuilder();
                    vCount = 0;
                }   
                else
                {
                    // Add the word to the string builder
                    vTempBuilder.Append(vWord + " ");
                    vCount++;
                }
            }
            return vResponse;
        }
        public async Task<List<string>> ParseDocuments()
        {
            AzureKeyCredential credential = new AzureKeyCredential(_subscriptionKey);
            DocumentAnalysisClient client = new DocumentAnalysisClient(new Uri(_endpoint), credential);

            //AnalyzeDocumentOptions vOptions = new AnalyzeDocumentOptions();
            //vOptions.Locale = "en-US";
            //vOptions. = FormContentType.Pdf;
            //vOptions.IncludeFieldElements = true;



            AnalyzeDocumentOperation operation = await client.AnalyzeDocumentFromUriAsync(WaitUntil.Completed, "prebuilt-document", _file2);

            var json = operation.GetRawResponse().Content.ToString();

            List<string> vStrings  = await GetringsFromDocument(operation);
            return vStrings;
        }

        private async Task<List<string>> GetringsFromDocument(AnalyzeDocumentOperation document)
        {
           
            List<string> vResponse = new List<string>();
            foreach (var vParagraph in document.Value.Paragraphs)
            {
                // Break vParagraph.Content out into 2000 word chunks
                string[] words = vParagraph.Content.Split(new[] { ' ', '\t', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
   

                if (words.Count() <= 2000)
                {
                    vResponse.Add(vParagraph.Content);
                }
                else
                {
                    List<string> vChunks = SplitWordsIntoChunks(words, 2000);
                    vResponse.AddRange(vChunks);
                }
            }
            return vResponse;
        }

        public async Task<List<DictionaryEntry>> GetEmbeddingsForParagraphs(List<string> StringCollection)
        {
            List<DictionaryEntry> vVectors = new List<DictionaryEntry>();
            Uri oaiEndpoint = new(_EmbeddingsEndPoint);
            string oaiKey = _EmbeddingKey;
            AzureKeyCredential credentials = new(oaiKey);
            
            OpenAIClient openAIClient = new(new Uri(_EmbeddingsEndPoint), credentials);

            foreach (var vString in StringCollection)
            {
                EmbeddingsOptions embeddingOptions = new(vString);
                var returnValue = openAIClient.GetEmbeddings("OpenAIModelTextEmbedding002", embeddingOptions);
                DictionaryEntry vEntry = new DictionaryEntry(returnValue.Value.Data[0].Embedding, vString);
                vVectors.Add(vEntry);
            }
            
    
            return vVectors;
        }   

        public async Task<bool> SaveDataToRedis(List<DictionaryEntry> data, string documentName)
        {
            // https://blog.baeke.info/2023/03/21/storing-and-querying-for-embeddings-with-redis/


            ConnectionMultiplexer redis = ConnectionMultiplexer.Connect(_RedisEndPoint);
            

           
           IDatabase db = redis.GetDatabase();
            var batch = db.CreateBatch();
            int vCount = 0;
            foreach (var vitem in data)
            {
      
                IReadOnlyList<float> vVectorValues = (IReadOnlyList<float>)vitem.Key;
                var vectorBytes = vVectorValues.SelectMany(f => BitConverter.GetBytes(f)).ToArray();
                HashEntry[] postHash = new HashEntry[]
                    {
                    new HashEntry(documentName, new RedisValue(vitem.Value.ToString())),
                    new HashEntry("embedding", vectorBytes)
                    };


                batch.HashSetAsync($"post:{vCount}", postHash);
                vCount++;
            }

           

            batch.Execute();

            bool vIndex = await CreateRedisIndex(redis, documentName);
            redis.Close();
            return true;  

            
        }


        public async Task<bool> CreateRedisIndex(ConnectionMultiplexer connection, string documentName)
        {

            IDatabase redisDb = connection.GetDatabase();

           // Field[] schemaFields =
           //{
           //    new TextField("url"),
           //    new VectorField(new FieldName("embedding"), VectorField.VectorAlgo.FLAT, new RedisValue[] { "TYPE": "FLOAT32", "DIM": 1536, "DISTANCE_METRIC": "COSINE" })
           // };

           
            // Schema definition
            Schema schema = new Schema();
            schema.AddField(new TextField(documentName));  // was url
           
            Dictionary<string, object> vectorOptions = new Dictionary<string, object>();
            vectorOptions["TYPE"] = "FLOAT32";
            vectorOptions["DIM"] = 1536;
            vectorOptions["DISTANCE_METRIC"] = "COSINE";
     

            FieldName vFieldName = new FieldName("embedding"); 
            
      
            VectorField vectorField = new VectorField(vFieldName, VectorField.VectorAlgo.FLAT, vectorOptions);
            schema.AddField(vectorField);
            try
            {
                FTCreateParams fTCreateParams = new FTCreateParams();
                //fTCreateParams.

                //redisDb.FT(0).Create("idx:users",
                //        new FTCreateParams().On(IndexDataType.JSON).Prefix("user:"),
                //        schema);

               // redisDb.FT(0).Create("posts", fTCreateParams, schema);
                //conn.ft("posts").create_index(fields=SCHEMA, definition=IndexDefinition(prefix=["post:"], index_type=IndexType.HASH))
               // except Exception as e:
                int vTimout = connection.TimeoutMilliseconds;
               // redisDb.FT.CreateIndex("posts", schema, new Client.ConfiguredIndexOptions().SetPrefix("post:").SetIndexType(Client.IndexType.HASH));
                redisDb.Execute("FT.CREATE", "posts", "SCHEMA", schema, "PREFIX", "post:", "INDEX_TYPE", "HASH");
                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine("Index already exists");
                return false;
            }


        }
    }
}
