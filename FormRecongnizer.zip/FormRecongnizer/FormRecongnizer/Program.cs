﻿// See https://aka.ms/new-console-template for more information
using FormRecongnizer;
using System.Collections;

FormRECOGNIZER vFrmR = new FormRECOGNIZER();
List<string> vList = await vFrmR.ParseDocuments();
List <DictionaryEntry> vTest = await vFrmR.GetEmbeddingsForParagraphs(vList);

bool vResponse = await vFrmR.SaveDataToRedis(vTest, "Medicare");


// 1 get JSON response 
// 2 call embeding 
// 3 store in vector
